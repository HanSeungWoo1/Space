package aaa;

public class ImplementationC implements InterfaceC {

	public void methodA() {
		System.out.println("ImplementationC-methodA() ����");
	}
	
	public void methodB() {
		System.out.println("ImplementationC-methodB() ����");
	}
	@Override
	public void methodC() {
		System.out.println("ImplementationC-methodC() ����");
	}

}
