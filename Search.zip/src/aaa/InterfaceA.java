package aaa;

public interface InterfaceA {
	public void methodA();
}
