package aaa;

public interface InterfaceB {
	public void methodB();
}
