package search;

public interface Searchable {
		void search(String url);
}

