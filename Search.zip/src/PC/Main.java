package PC;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name = sc.next();
		String school = sc.next();
		int grade = sc.nextInt();
		sc.close();
		
		Student stu = new Student();
		stu.setName(name);
		stu.setSchool(school);
		stu.setGrade(grade);
		stu.print();
	}

}

class Student {
	private String name;
	private String school;
	private int grade;
	
	public void setName(String name) {
		this.name = name;
	}
	System.out.println(name);
	System.out.println(school);
	System.out.println(grade);
	
	Student stu = new Student();
}
}
