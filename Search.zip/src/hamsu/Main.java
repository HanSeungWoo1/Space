package hamsu;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int inp = sc.nextInt();
		sc.close();
		System.out.println(inp);
	
		
		for (int i = 0; i < inp; i++) {
			printStr();
//		Main m = new Main();
//		m.printStr();
//		String str = "~!@#$^&*()_+|";
//		printStr();
	}
	}
	public static void printStr() {
		System.out.println("~!@#$^&*()_+|");
	}

}
