package Vehicle;

public interface Vehicle {
	public void run();
}
