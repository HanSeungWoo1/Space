package p387;

public class SoundableExample {

	public static void printSound(Soundable soundable) {
		System.out.println(soundable.sound());
		// TODO Auto-generated method stub

	}
	public static void main(String[] args) {
		printSound(new Cat());
		printSound(new Dog());
	}

}
