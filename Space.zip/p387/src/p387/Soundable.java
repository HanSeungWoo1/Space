package p387;

public interface Soundable {
	String sound();
}
