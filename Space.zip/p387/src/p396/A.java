package p396;

public class A {
	
	B field =
}
