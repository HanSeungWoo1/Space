package p388;

public interface Action {
	void work();
}
