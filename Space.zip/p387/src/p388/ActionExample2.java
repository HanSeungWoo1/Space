package p388;

public class ActionExample2 {

	public static void main(String[] args) {
			Action action = new Doit();
					
					
					
					
			action.work();

	}

}
