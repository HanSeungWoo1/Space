package p388;

public class ActionExample {

	public static void main(String[] args) {
			Action action = new Action() {

				@Override
				public void work() {
					// TODO Auto-generated method stub
					
				}
			};	
			action.work();

	}

}
