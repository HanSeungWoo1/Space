package de;

public interface ChildInterface2 extends ParentInterface {
	@Override
	public default void method2() { /*���๮*/ }   //������
	
	public void method3();

	ChildInterface2 ci2 = new ChildInterface2() {
		@Override
		public void method1() {/*���๮*/}
		@Override
		public void method3() {/*���๮*/}
	};
	
	ci2.method1();
	ci2.method2();
	ci2.method3();
}
