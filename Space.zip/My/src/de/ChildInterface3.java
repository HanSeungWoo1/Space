package de;

public interface ChildInterface3 extends ParentInterface {
	@Override
	public void method2();
	public void method3();
	
	ChildInterface3 ci3 = new ChildInterface3() {
		@Override
		public void method1() {/*���๮*/}
		@Override
		public void method2() {/*���๮*/}
		@Override
		public void method3() {/*���๮*/}
	};
	
	
	ci3.method1();
	ci3.method2();
	ci3.method3();
}
