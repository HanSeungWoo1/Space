package de;

public interface ChildInterface1 extends ParentInterface {
	public void method3();
	
	ChildInterface1 ci1 = new ChildInterface1() {
		@Override
		public void method1() { /*���๮*/ }
		@Override
		public void method3() { /*���๮*/ }
	
	};
	ci1.method1();
	ci1.method2();
	ci1.method3();
}

