
public class MyClassA implements MyInterface {

	@Override
	public void method1() {
		System.out.println("MyClassA-method1() ����");

	}

}
