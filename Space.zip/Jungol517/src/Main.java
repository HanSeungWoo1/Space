import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	double d1 = sc.nextDouble();
	double d2 = sc.nextDouble();
	double d3 = sc.nextDouble();
	sc.close();
	
	System.out.printf("%.3f \n",d1);
	System.out.printf("%.3f \n",d2);
	System.out.printf("%.3f \n",d3);
	
	String str = String.format("%.3f", d1);
	String str1 = String.format("%.3f", d2);
	String str2 = String.format("%.3f", d3);
	System.out.println(str);
	System.out.println(str1);
	System.out.println(str2);

	}

}
