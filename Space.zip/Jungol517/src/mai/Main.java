package mai;

public class Main {

	public static void main(String[] args) {
	double d1 = 12.3456;
	double d2 = 1234.56;
	double d3 = 12345.6789;
	
	System.out.printf(" ","%f\n", d1);
	System.out.printf("%f\n", d2);
	System.out.printf("%f\n", d3);
			
	}

}
