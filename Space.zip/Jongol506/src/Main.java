public class Main {

	public static void main(String[] args) {
		int a = 170;
		String b = "My height";
		String c = "My weight";
		double d = 68.6;
		
		System.out.println(b);
		System.out.println(a);
		System.out.println(c);
		System.out.printf("%.6f",d);

	}

}
